history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname
hostnamectl set-hostname TPServer
nano /etc/hosts
cat /etc/hosts
sed -i '/^127\.0\.1\.1/s/debian/TPServer/g' /etc/hosts
cat /etc/hosts
reboot
hostname
cat /etc/hostname
hostnamectl
grep 127.0.1.1 /etc/hosts
cat /etc/debian_version
poweroff
cat /etc/debian_version
ip -br a
ping -c 3 deb.debian.org
df -h /
cat /etc/apt/souces.list
cat /etc/apt/sources.list
ls /etc/apt/sources.list.d/
apt-get update && apt-get upgrade -y
cp /etc/apt/sources.list /etc/apt/sources.list.bak
ping -c 1 security.debian.org
cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
EOF

cat /etc/apt/sources.list
apt-get update
ls /etc/apt/sources.list*
apt-get upgrade --without-new-pkgs
apt-get dist-upgrade
cat /etc/debian_version
ls /boot/vmlinuz*
grep -m1 vmlinuz /boot/grub/grub.cfg
dpkg --audit
reboot
cat /etc/debian_version
cat /etc/os-release
uname -r
hotnamectl
hostnamectl
apt-get autoremove
dpkg --audit
df -h /
poweroff
apt-get install nano
ip -br a
ip route
cat /etc/resolv.conf
cat /etc/network/interfaces
ip a show enp0s3
ls /etc/network/interfaces.d/
ping -c 2 192.168.1.200
ip neigh show 192.168.1.200
cp /etc/network/interfaces /etc/network/interfaces.bak
nano /etc/network/interfaces
cat /etc/network/interfaces
sed -i 's/inet dhcp/inet static/' /etc/network/interfaces
cat /etc/network/interfaces
ip a show enp0s3
ping -c 2 192.168.1.200
ip neigh show 192.168.1.200
ls /etc/network/interfaces.d/
reboot
ip -br a
ip route
ip a show enp0s3
ping -c 3 192.168.1.1
ping -c 3 deb.debian.org
reboot
poweroff
hostname; ip -br a
exit
ls -la /root
tar -tzvf /root/Material_Adicional_TPVMCA.tar.gz
tar -xzvf /root/Material_Adicional_TPVMCA.tar.gz -C /root --strip-components=1 --no-same-owner
chmod 600 /root/clave_privada.txt
ls -la /root
ls -la /root/.ssh
systemctl status ssh
apt-get install openssh-server
systemctl status ssh
ss -tlnp | grep :22
chmod 700 /root/.ssh
cat /root/clave_publica.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
ls -la /root/.ssh
ssh-keygen -l -f /root/.ssh/authorized_keys
cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
sed -i 's/^#\?PubkeyAuthentication.*/PubkeyAuthentication yes/' /etc/ssh/sshd_config
grep -E '^(PermitRootLogin|PubkeyAuthentication)' /etc/ssh/sshd_config
sshd -t
systemctl restart ssh
sshd -T | grep -Ei '^(permitrootlogin|pubkeyauthentication)'
ssh -i /root/clave_privada.txt root@localhost
poweroff
hostname; ip -br a
dpkg -l | grep -E 'apache2|php|mariadb'
apt-get update
apt-get install apache2
systemctl status apache2
ss -tlnp | grep :80
apt-get install php libapache2-mod-php php-mysql
php -v
apache2ctl -M | grep php
php -m | grep mysqli
ls -l /var/www/html
mv /var/www/html/index.html /var/www/html/index.html.bak
cp /root/index.php /root/logo.png /var/www/html/
ls -l /var/www/html
tail -3 /var/log/apache2/error.log
tail -3 /var/log/apache2/error.log
exit
poweroff
apt-get install mariadb-server
systemctl status mariadb --no-pager
ss -tlnp | grep 3306
mariadb --version
cat -A /root/db.sql | head -5
sed 's/\r$//' /root/db.sql | mariadb
mariadb -e "SHOW DATABASES;"
mariadb ingenieria -e "SHOW TABLES; SELECT COUNT(*) FROM notas;"
mariadb -e "SELECT User, Host FROM mysql.user;"
mariadb -u lcars -pNCC1701D ingenieria -e "SELECT * FROM alumnos;"
php /var/www/html/index.php | grep -o '<tr>' | wc -l
systemctl is-enabled apache2 mariadb
systemctl is-active apache2 mariadb
reboot
poweroff
lsblk
fdisk -l /dev/sdc
fdisk /dev/sdc
lsblk /dev/sdc
fdisk -l /dev/sdc
mkfs.ext4 -L www /dev/sdc1
mkfs.ext4 -L backup /dev/sdc2
lsblk -f /dev/sdc
mkdir /www_dir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h /www_dir /backup_dir
ls -la /www_dir
clear
cp /etc/fstab /etc/fstab.bak
blkid /dev/sdc1 /dev/sdc2
echo "UUID=$(blkid -s UUID -o value /dev/sdc1) /www_dir ext4 defaults 0 2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2) /backup_dir ext4 defaults 0 2" >> /etc/fstab
tail -3 /etc/fstab
systemctl daemon-reload
umount /www_dir /backup_dir
mount -a
findmnt --verify
df -h /www_dir /backup_dir
reboot
lsblk
fdisk -l
df -h /www_dir /backup_dir
findmnt /www_dir
cp /root/index.php /root/logo.png /www_dir/
ls -l /www_dir
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.bak
cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.bak
sed -i 's|DocumentRoot /var/www/html|DocumentRoot /www_dir|' /etc/apache2/sites-available/000-default.conf
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
cat >> /etc/apache2/apache2.conf << 'EOF'

<Directory /www_dir/>
    Options Indexes FollowSymLinks
    AllowOverride None
    Require all granted
</Directory>
EOF

tail -6 /etc/apache2/apache2.conf
apache2ctl configtest
systemctl reload apache2
cp /etc/apache2/sites-available/000-default.conf.bak /etc/apache2/sites-available/000-default.conf
cp /etc/apache2/apache2.conf.bak /etc/apache2/apache2.conf
systemctl reload apache2
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
tail -3 /etc/apache2/apache2.conf
sed -i 's|DocumentRoot /var/www/html|DocumentRoot /www_dir|' /etc/apache2/sites-available/000-default.conf
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
cat >> /etc/apache2/apache2.conf << 'EOF'

<Directory /www_dir/>
    Options Indexes FollowSymLinks
    AllowOverride None
    Require all granted
</Directory>
EOF

tail -6 /etc/apache2/apache2.conf
apache2ctl configtest
systemctl reload apache2
mv /var/www/html/index.php /var/www/html/index.php.prueba
mv /var/www/html/index.php.prueba /var/www/html/index.php
tail -3 /var/log/apache2/access.log
mv /var/www/html/index.php /var/www/html/index.php.prueba
ls /var/www/html
mv /var/www/html/index.php.prueba /var/www/html/index.php
cat /proc/partitions > /opt/particion
cat /opt/particion
poweroff
mkdir /opt/scripts
cat > /opt/scripts/backup_full.sh << 'EOF'
#!/bin/bash
# backup_full.sh - TPI Computacion Aplicada, consigna 5
# Uso: backup_full.sh ORIGEN DESTINO

# 5.5: ayuda
if [[ "$1" == "-help" ]]; then
    echo "Uso: $0 ORIGEN DESTINO"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Crea DESTINO/<carpeta>_bkp_AAAAMMDD.tar.gz"
    exit 0
fi

# 5.4: argumentos (origen y destino)
if [[ $# -ne 2 ]]; then
    echo "Error: faltan argumentos. Ayuda: $0 -help"
    exit 1
fi
ORIGEN=$1
DESTINO=$2

# 5.6: validar origen y destino
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: el origen $ORIGEN no existe"
    exit 1
fi
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: el destino $DESTINO no existe"
    exit 1
fi
if ! mountpoint -q "$DESTINO"; then
    echo "Error: en $DESTINO no hay una particion montada"
    exit 1
fi

# 5.2 y 5.3: nombre con fecha y backup
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")_bkp_$FECHA.tar.gz
tar -czf "$DESTINO/$NOMBRE" "$ORIGEN"
echo "Backup creado: $DESTINO/$NOMBRE"
EOF

cat /opt/scripts/backup_full.sh
chmod 755 /opt/scripts/backup_full.sh
ls -l /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh var/logs /backup_dir
/opt/scripts/backup_full.sh /var/log /tmp
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh /var/logs /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls -lh /backup_dir
tar -tzf /backup_dir/www_dir_bkp_$(date +%Y%m%d).tar.gz
systemctl status cron
crontab -e
crontab -l
date
54 21 * * * /opt/scripts/backup_full.sh /www_dir /backup_dir
crontab -e
ls -l /backup_dir
journalctl -u cron --since ¨5 min ago¨
journalctl -u cron --since ¨21:50¨
journalctl -u cron --since 21:50
crontab -e
crontab -l
df -h
du -sh /root /etc /opt /www_dir /backup_dir /var
mkdir /home/entregables
poweroff
