#!/bin/bash
# backup_full.sh - TPI Computacion Aplicada, consigna 5
# Uso: backup_full.sh ORIGEN DESTINO

# 5.5: ayuda
if [[ "$1" == "-help" ]]; then
    echo "Uso: $0 ORIGEN DESTINO"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Crea DESTINO/<carpeta>_bkp_AAAAMMDD.tar.gz"
    exit 0
fi

# 5.4: argumentos (origen y destino)
if [[ $# -ne 2 ]]; then
    echo "Error: faltan argumentos. Ayuda: $0 -help"
    exit 1
fi
ORIGEN=$1
DESTINO=$2

# 5.6: validar origen y destino
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: el origen $ORIGEN no existe"
    exit 1
fi
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: el destino $DESTINO no existe"
    exit 1
fi
if ! mountpoint -q "$DESTINO"; then
    echo "Error: en $DESTINO no hay una particion montada"
    exit 1
fi

# 5.2 y 5.3: nombre con fecha y backup
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")_bkp_$FECHA.tar.gz
tar -czf "$DESTINO/$NOMBRE" "$ORIGEN"
echo "Backup creado: $DESTINO/$NOMBRE"
